from django.urls import include, path
from django.views.generic import TemplateView
from .views import AccountLogin
# from CSPlatform.core import views

# urlpatterns = [
#     path('pie-chart/', views.pie_chart, name='pie-chart'),
# ]


urlpatterns = [
    # path('', show.as_view(), name='view'),
    # path('page', Bargraph.as_view(), name='view')
    path('register', AccountLogin.as_view(), name='login')


]
