from django.views import View
from django.http import HttpResponse

from .forms import RegisterForm
from django.shortcuts import render, redirect
from CSPlatform.models import City, Country, Register
from django.db.models import Max, Min, Avg
from django.views.generic import TemplateView
from django.contrib.auth.models import User, auth
from django.contrib import messages


# class show(View):
#     template_name = 'CSPlatform/basic.html'
#     print("hello brother ")
#
#     def get(self, request):
#         obj = Survey.objects.all()
#         context = {
#             'table': obj
#         }
#
#         # p = Survey(Comapny_name='Apress', Realtionship_name='Berkeley',
#         #            Survey_name='shainky', Name='shashank1',
#         #            Email='shashank@gmail.com', Score='10',
#         #            Created_date='2020-02-12 15:08:42', updated_date='2020-02-12 15:08:42')
#         # p.save()
#
#         return render(request, self.template_name, context)


# class show(View):
#     template_name = 'CSPlatform/pie-chart.html'
#
#     def get(self, request):
#
        # labels = []
        # data = []
        # obj = Country.objects.values('name') \
        #     .annotate(max=Max('lifeexpectancy'), avg=Avg('lifeexpectancy')) \
        #     .order_by('-max')[0:1]
        # print("///////////////", obj)
        #
        # context = {
        #             'maximum': obj
        #         }
        #
        # return render(request, self.template_name, context)




# class show(View):
#     template_name = 'CSPlatform/Histogram.html'
#     print("////////////Class")
#     def get(self, request):
#         labels = []
#         data = []
#         queryset = City.objects.values('countrycode') \
#                     .annotate(max=Max('population'), min=Min('population')) \
#                       .order_by('-population')[0:1]
#         print("/////////////////////////////", queryset, "//////////////////")
#         for city in queryset:
#             labels.append(city.name),
#             data.append(city.population)
#             context = {
#                 'labels': labels,
#                 'data': data,
#                 }
#             print("///////////////////,", context)
#         return render(request, self.template_name, context)
#



    # template_name = 'CSPlatform/pie_chart.html'
    # def get(self, request):
    #     labels = []
    #     data = []
    #
    #     print("/////////////////  Enterd to the class")
    #
    #     queryset = City.objects.order_by('-population')[:5]
    #     for city in queryset:
    #         labels.append(city.name)
    #         data.append(city.population)
    # context= {
        #         'labels': labels,
        #         'data': data,
    #           }
    #     return render(request, self.template_name, context)

#
# class Bargraph(TemplateView):
#     template_name='CSPlatform/Histogram.html'
#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context["qs"] = City.objects.order_by('-population')[:9]
#         print("///////////////", context)
#         return context


class AccountLogin(View):
    print("In Account Login page")
    template_name = 'CSPlatform/loginandregister.html'

    def get(self, request):
        form=RegisterForm()
        context={ 'form': form}
        print("This is the get function call")
        return render(request, self.template_name, context)

    def post(self, request):
        print("got inside post method call")

        form=RegisterForm(request.POST)
        print("THIS IS PRINT ", form)
        if form.is_valid():
            print("from data", form.cleaned_data)
            form.save()
        else:
            print("This is error ", form.errors)
            messages.error(request, 'This is an error!!')

        return redirect('login')



    # def post(self, request):
    #     email = request.POST.get["email"]
    #     password = request.POST.get["password"]
    #     print("Entered to post function call")
    #
    #     if email and password:
    #         print("Coming to if statemnt preoperly")
    #         messages.success(request, 'You have logged in Congrats !!')
    #     return redirect('view')


        # login_id = request.method == 'POST'
        # print("THis is the loginid ", login_id)
        # if login_id:
        #     email = request.POST['email']
        #     password = request.POST['password']
        #
        #     user = Register.authenticate(email=email, password=password)
        #     print("THIS IS THE USSER", user)
        #     if user is not None:
        #         auth.login(request, user)
        #         messages.success(request, 'Login User !!')
        #         print("This is the success ")
        #     else:
        #         messages.error(request, 'Entered credentials are wrong !! Try again ')
        #         print("THIS IS SUCCESFULL MSG")
        #         return redirect('login')
        #
        # else:
        #     messages.error(request, 'not correct')
        #
        # return render(request, self.template_name)
