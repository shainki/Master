from .models import Register
from django import forms
from django.forms import ModelForm
from django.contrib import messages


class RegisterForm(forms.ModelForm):
    first_name = forms.CharField(widget=forms.TextInput(), required=True)
    email = forms.EmailField(required=True)
    password = forms.CharField(widget=forms.PasswordInput(), required=True, max_length=20)
    confirm_password = forms.CharField(widget=forms.PasswordInput(), required=True, max_length=20)

    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)

    class Meta:

        model = Register
        fields = ['first_name', 'email', 'password']


#         =============Form Ends here==========



# This is for the password and confirm password match
    def clean_password(self):
        # Check that the two password entries match
        password = self.cleaned_data.get("password1")
        confirm_password = self.cleaned_data.get("password2")
        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords don't match")
        return password


#     This is the validation check for the password filed
#     def clean_password(self, *args, **kwargs):
#         password=self.cleaned_data.get("password")
#         if not "@" and "1" or "2" or "3" or "4" or "5" or "6" or "7" or "8" or "9" or "0":
#             forms.ValidationError("This is not a valid format")
#         else:
#             return password

# THIS IS TEH ROUGH DATA

#
# from django.core.exceptions import ValidationError
# from django.utils.translation import ugettext as _
# import re
#
# class ComplexPasswordValidator:
#     """
#     Validate whether the password contains minimum one uppercase, one digit and one symbol.
#     """
#     def validate(self, password, user=None):
#         if re.search('[A-Z]', password)==None and re.search('[0-9]', password)==None and re.search('[^A-Za-z0-9]', password)==None:
#         raise ValidationError(
#                _("This password is not strong."),
#                 code='password_is_weak',
#             )
#
#     def get_help_text(self):
#         return _("Your password must contain at least 1 number, 1 uppercase and 1 non-alphanumeric character.")
